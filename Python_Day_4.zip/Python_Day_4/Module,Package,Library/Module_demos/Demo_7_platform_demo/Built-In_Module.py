
# platform is an in built module in python

#import platform

#print(platform.platform())

from platform import platform
print(platform())

