def fun2():
    return "welcome to fun2"

print("we are inside Second.py")