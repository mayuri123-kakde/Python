from First import disp1,disp2
from Second import fun2


disp1(100)
disp2(300)
print(fun2())

