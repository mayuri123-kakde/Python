import First,Second


First.disp1(100)
First.disp2(300)
print(Second.fun2())





