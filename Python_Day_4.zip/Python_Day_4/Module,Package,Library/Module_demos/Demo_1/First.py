def disp1(val1):
	print(val1)
def disp2(val2):
	print(val2)

