var=100
print(var)
del var
print(var)    #  NameError: name 'var' is not defined. Did you mean: 'vars'?
