class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age

p1=Person("Sachin",25)
print(p1)