# invoking "docstring"  of inbuilt functions

print(print.__doc__)
print(int.__doc__)