# we can change the labels or indexes
from pandas import *

first=Series([10,20,30,40,50],index=['p','q','r','s','t'])
print(first)