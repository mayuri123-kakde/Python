# Series object is a one-dimensional labelled or indexed  array

import pandas as pd

first=pd.Series([10,20,30,40,50])
print(first)