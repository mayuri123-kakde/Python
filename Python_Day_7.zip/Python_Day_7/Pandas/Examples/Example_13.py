# how to read JSON file

from pandas import *

# mydataframe=read_json("myfile.json")
mydataframe=read_json("details.json")

print(mydataframe)
