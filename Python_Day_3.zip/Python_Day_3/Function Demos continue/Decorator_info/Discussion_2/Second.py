def div(a,b):
    print(a/b)

div(4,8)   # what if numerator is less than denominator, how will you change the function?