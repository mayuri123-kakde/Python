def div(a,b):
    if(a<b):
        a,b=b,a   # logic to swap numerator and denominator if former is less that later
    print(a/b)

div(4,8)   