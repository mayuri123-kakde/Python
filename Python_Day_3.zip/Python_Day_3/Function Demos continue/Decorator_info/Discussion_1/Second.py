# let's write initialization and release 

def fun1():
    print("Initialising Resources")
    print("Important task1")
    print("Releasing Resources")

def fun2():
    print("Initialising Resources")
    print("Important task2")
    print("Releasing Resources")

def fun3():
    print("Initialising Resources")
    print("Important task3")
    print("Releasing Resources")

def fun4():
    print("Initialising Resources")
    print("Important task4") 
    print("Releasing Resources")

fun1()
fun2()
fun3()
fun4()
