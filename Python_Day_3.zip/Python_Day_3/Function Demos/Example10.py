def show(var1,var2):
    print(var1,"\t",var2)


def myfun():
    show("Rahul",30)
myfun()




