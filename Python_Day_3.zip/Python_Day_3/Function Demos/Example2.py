def myfun1():
    num1=100
    print(num1)
    str="hello"
    print(str)
    ch='A'
    print(ch)
    fl=2.3
    print(fl)
    dl=4.5
    print(dl)
    val=True
    print(val)
    num1="well done"  # redeclaring a variable
    print(num1)
myfun1()
print("Done")