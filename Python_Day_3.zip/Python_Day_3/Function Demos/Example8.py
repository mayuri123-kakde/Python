
def disp():
    print("inside disp")

def myfun():
    print("inside main")
    disp()
myfun()



