# default arguments of the function

def disp(var1,var2=20):
	print(var1,"\t",var2)
	
def fun():
	disp(10)
	disp(100,200)
fun()


