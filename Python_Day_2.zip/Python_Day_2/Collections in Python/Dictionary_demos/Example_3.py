mydict = {1:'Amar',2:'Sachin',3:'Vishal'}

print(mydict)

print(mydict[1])
print(mydict[2])
print(mydict[3])

mydict[4]='Arun'   # adding a pair in dictionary
print(mydict)
print(mydict.keys())   # print all the keys of dictionary
print(mydict.values())  # print all the values of dictionary

