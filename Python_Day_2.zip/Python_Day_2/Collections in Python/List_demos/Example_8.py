# Pop() function can also be used to remove and return an element from the list,
# but by default it removes only the last element of the list,
# to remove an element from a specific position of the List,
# the index of the element is passed as an argument to the pop() method.

mylist = [10,"hello",4.5,False,'A']

print(mylist)

mylist.pop()  # by default removes the last element
print(mylist)




