# Concatenation of Tuples
# Concatenation is only possible with tuples. It can't be concatenated to other kinds, such lists.

mytuple1 = (10,20,30,40)

mytuple2 = ("hello","welcome","Bye")

mytuple3 = mytuple1 + mytuple2

print("Combined tuple is")
print(mytuple3)

# concatenation of lists

mylist1 = [100,200,300]
mylist2= [True,False,"Hi"]
mylist3 = mylist1 + mylist2
print("combined list is ")
print(mylist3)