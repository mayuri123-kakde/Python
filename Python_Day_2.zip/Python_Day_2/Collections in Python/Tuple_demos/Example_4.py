# creating a tuple with tuple function and a string

mytuple1 = tuple("Internationalization")

for i in mytuple1:
    print(i)