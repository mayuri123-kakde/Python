# "set()" function to convert a list with duplicate values into set

mylist = [1,2,3,4,5,6,5,5,1,8,9,10]

print(mylist)
print(type(mylist))

# convert list into set

myset = set(mylist)
print(myset)
print(type(myset))

# add method to add values in the set
myset.add(12)
myset.add(15)
print(myset)