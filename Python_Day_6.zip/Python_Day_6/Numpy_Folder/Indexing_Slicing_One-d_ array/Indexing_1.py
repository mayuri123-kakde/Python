from numpy import *

first=array([10,20,30,40])
# indexing from left to right

print(first[0],"\t",first[1],"\t",first[2],"\t",first[3])

# indexing from right to left

print("\n")
print(first[-1],"\t",first[-2],"\t",first[-3],"\t",first[-4])