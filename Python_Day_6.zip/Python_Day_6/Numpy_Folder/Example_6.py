# arange to give range of numbers
import numpy as np
first=np.arange(20,25)    # here 25 is exclusive
print(first)

second=np.arange(10,20,2)       # start with 10, increment by 2 and here 20 is exclusive
print(second)

