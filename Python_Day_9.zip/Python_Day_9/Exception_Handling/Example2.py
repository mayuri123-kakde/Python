print("Let's open a file")
open("d:\\sample1.txt","r")
print("done")