import os

os.rename("iris.csv","temp.txt")
print("Done")

