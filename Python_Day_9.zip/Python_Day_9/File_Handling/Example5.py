# how to read from a file


with open("details.json","r") as f:
    data=f.read()
    print(data)

print("Done")


