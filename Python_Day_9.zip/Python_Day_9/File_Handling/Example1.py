from os import path

print("File Exists\t",path.exists("web.xml"))
print("Directory Exists\t",path.exists("d:\\new"))

